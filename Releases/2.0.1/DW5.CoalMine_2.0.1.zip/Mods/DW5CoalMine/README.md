# **DWFiv3s Coal Mine**

***v2.0.1**
- Expands out the Incoming Tracks to provide well over 100 incoming cars
- Expands mining supplies to accomidate more (you'll need it!)
- 6 Outbound Storage Tracks, the "hump yard" now recieves the cars directly, can store over 100 cars
- Production has been sped up past that of Nick's Production mod, so you'll be busy
- Removed the "Cheat Tunnel" 
- Lengthended the hump yard to accomicdate mote

Special thanks to Sgt Moloch for assisting in the teleportation side, wouldnt have been possible otherwise.